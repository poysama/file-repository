package MogileFS::Plugin::MetaData;

use strict;
use warnings;

our $VERSION = '1.02';
$VERSION = eval $VERSION;

use MogileFS::Worker::Query;

my %name_to_nameid;
my %nameid_to_name;

sub load {
    MogileFS::register_worker_command('delete_metadata', sub {
        my ($worker, $args) = @_;
        my $fid;

        $fid = get_fid($worker, $args) or return $fid;

        MogileFS::Plugin::MetaData::delete_metadata($fid);

        return $worker->ok_line;
    });

    MogileFS::register_worker_command('get_metadata', sub {
        my ($worker, $args) = @_;
        my $fid;

        $fid = get_fid($worker, $args) or return $fid;

        my $ret = MogileFS::Plugin::MetaData::get_metadata($fid);

        return $worker->ok_line($ret);
    });

    MogileFS::register_worker_command('set_metadata', sub {
        my ($worker, $args) = @_;
        my $fid;

        $fid = get_fid($worker, $args) or return $fid;

        delete($args->{domain});
        delete($args->{key});

        MogileFS::Plugin::MetaData::set_metadata($fid, $args);

        return $worker->ok_line;
    });

    return 1;
}

sub get_fid {
    my ($worker, $args) = @_;

    # get and validate domain id
    my $dmid = $worker->check_domain($args)
        or return $worker->err_line('domain_not_found');

    #  validate key
    my $key = $args->{key} or return $worker->err_line("no_key");

    # get fid
    my $fid;

    Mgd::get_store()->slaves_ok(sub {
            $fid = MogileFS::FID->new_from_dmid_and_key($dmid, $key);
        });

    return ($fid->{fidid} or $worker->err_line("unknown_key"));
}

sub unload {
    return 1;
}

sub delete_metadata {
    my ($fid) = @_;

    my $dbh = Mgd::get_store()->dbh();

    $dbh->do('DELETE FROM plugin_metadata_data WHERE fid=?', undef, $fid);

    warn "DBI Error while deleting fid '$fid': " . $dbh->errstr if $dbh->err;
}

sub get_metadata {
    my ($fid) = @_;

    my $dbh = Mgd::get_store()->dbh();

    my $meta_by_name = {};

    my $sth = $dbh->prepare('SELECT nameid, data FROM plugin_metadata_data WHERE fid=?');

    $sth->execute($fid);

    die "DBH Error on SELECT: " . $dbh->errstr if $dbh->err;

    while (my ($nameid, $data) = $sth->fetchrow_array) {
        my $name = $nameid_to_name{$nameid};
        unless (exists $nameid_to_name{$nameid}) {
            ($name) = $dbh->selectrow_array('SELECT name FROM plugin_metadata_names WHERE nameid=?', undef, $nameid);
            die "DBH Error while getting nameid->name mapping: " . $dbh->errstr if $dbh->err;
            $nameid_to_name{$nameid} = $name;
            $name_to_nameid{$name} = $nameid;
        }
        $meta_by_name->{$name} = $data;
    }

    return $meta_by_name;
}

sub set_metadata {
    my ($fid, $meta_by_name) = @_;

    my $dbh = Mgd::get_store()->dbh;

    my $meta_by_nameid = {};

    # Flag indicating if we've inserted and decided to redo the loop, to prevent infinite loops.
    my $inserted = 0;

    foreach my $name (keys %$meta_by_name) {
        my $nameid = $name_to_nameid{$name};

        unless (exists $name_to_nameid{$name}) {
            ($nameid) = $dbh->selectrow_array('SELECT nameid FROM plugin_metadata_names WHERE name=?', undef, $name);
            warn "DBH Error on SELECT: " . $dbh->errstr if $dbh->err;

            if($nameid) {
                $nameid_to_name{$nameid} = $name;
                $name_to_nameid{$name} = $nameid;
            }
        }

        if ($inserted && ! $nameid) {
            die "Bailing out, unable to get a metadata nameid for '$name'";
        }

        unless ($nameid) {
            $dbh->do('INSERT IGNORE INTO plugin_metadata_names (name) VALUES (?)', undef, $name);
            warn "DBH Error on insert: " . $dbh->errstr if $dbh->err;
            $nameid = $dbh->{mysql_insertid};

            unless ($nameid) {
                $inserted = 1;
                redo;
            }
        }

        $nameid += 0;

        $meta_by_nameid->{$nameid} = $meta_by_name->{$name};
    } continue {
        $inserted = 0;
    }

    foreach my $nameid (keys %$meta_by_nameid) {
        $dbh->do('INSERT INTO plugin_metadata_data (fid, nameid, data) VALUES (?, ?, ?)
                  ON DUPLICATE KEY UPDATE data=VALUES(data)',
                 undef, $fid, $nameid, $meta_by_nameid->{$nameid});
        warn "DBH Error on insert of metadata: " . $dbh->errstr if $dbh->err;
    }

    return 1;
}

package MogileFS::Store;

use MogileFS::Store;

use strict;
use warnings;

sub TABLE_plugin_metadata_names { "
CREATE TABLE plugin_metadata_names (
    nameid BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    PRIMARY KEY (nameid)
)
" }

sub TABLE_plugin_metadata_data { "
CREATE TABLE plugin_metadata_data (
    fid BIGINT UNSIGNED NOT NULL,
    nameid BIGINT UNSIGNED NOT NULL,
    data VARCHAR(255) NOT NULL,
    PRIMARY KEY (fid, nameid)
)
" }

__PACKAGE__->add_extra_tables("plugin_metadata_names", "plugin_metadata_data");

1;
